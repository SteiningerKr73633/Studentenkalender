# Android Alarm Clock

Current Trends In Software Engineering - Assignment 2

## Features

- [x] Set time in 24hr clock
- [x] Playback ringtone when selecting
- [x] Ask user to answer a question to dismiss alarm
- [x] Multiple alarms
- [x] Delete alarm
- [ ] Edit alarm
- [ ] Disable alarm


### TODO 

Polish UI